#pragma once

#include "Common.h"
#include "GameWindow.h"

// Classes used in game.  For a new class, declare it here and provide a pointer to an object of this class below.  Then, in Game.cpp, 
// include the header.  In the Game constructor, set the pointer to NULL and in Game::Initialise, create a new object.  Don't forget to 
// delete the object in the destructor.   
class CCamera;
class CSkybox;
class CShader;
class CShaderProgram;
class CPlane;
class CFreeTypeFont;
class CHighResolutionTimer;
class CSphere;
class COpenAssetImportMesh;
class CAudio;
class CPyramid;
class CCube;
class CCatmullRom;
class CHeightMapTerrain;

class Game {
private:
	// Three main methods used in the game.  Initialise runs once, while Update and Render run repeatedly in the game loop.
	void Initialise();
	void Update();
	void Render();

	// Pointers to game objects.  They will get allocated in Game::Initialise()
	CSkybox *m_pSkybox;
	CCamera *m_pCamera;
	vector <CShaderProgram *> *m_pShaderPrograms;
	CPlane *m_pPlanarTerrain;
	CFreeTypeFont *m_pFtFont;
	COpenAssetImportMesh *m_pCamaroMesh;
	COpenAssetImportMesh *m_pCondorMesh;
	COpenAssetImportMesh* m_pCactusMesh;
	CSphere *m_pSphere;
	CHighResolutionTimer *m_pHighResolutionTimer;
	CAudio *m_pAudio;
	CPyramid *m_pPyramid;
	CCube *m_pCube;
	CCatmullRom *m_pCatmullRom;
	CHeightMapTerrain* m_pHeightmapTerrain;
	

	// Some other member variables
	double m_dt;
	int m_framesPerSecond;
	bool m_appActive;
	string viewpoint;
	float m_currentDistance;
	float m_t;
	glm::vec3 m_condorPosition;
	glm::mat4 m_condorOrientation;
	glm::vec3 m_camaroPosition;
	glm::vec3 m_nextCamaroPosition;
	glm::mat4 m_camaroOrientation;
	int m_timePassed;
	float m_rotY;

	// Fernet 
	glm::vec3 T;
	glm::vec3 B;
	glm::vec3 N;

	glm::vec3 T2;
	glm::vec3 B2;
	glm::vec3 N2;



public:
	Game();
	~Game();
	static Game& GetInstance();
	LRESULT ProcessEvents(HWND window,UINT message, WPARAM w_param, LPARAM l_param);
	void SetHinstance(HINSTANCE hinstance);
	WPARAM Execute();

private:
	static const int FPS = 60;
	void DisplayFrameRate();
	void GameLoop();
	void ChangeViewPoint(string viewpoint);
	GameWindow m_gameWindow;
	HINSTANCE m_hInstance;
	int m_frameCount;
	double m_elapsedTime;


};
