/* 
OpenGL Template for INM376 / IN3005
City University London, School of Mathematics, Computer Science and Engineering
Source code drawn from a number of sources and examples, including contributions from
 - Ben Humphrey (gametutorials.com), Michal Bubner (mbsoftworks.sk), Christophe Riccio (glm.g-truc.net)
 - Christy Quinn, Sam Kellett and others

 For educational use by Department of Computer Science, City University London UK.

 This template contains a skybox, simple terrain, camera, lighting, shaders, texturing

 Potential ways to modify the code:  Add new geometry types, shaders, change the terrain, load new meshes, change the lighting, 
 different camera controls, different shaders, etc.
 
 Template version 5.0a 29/01/2017
 Dr Greg Slabaugh (gregory.slabaugh.1@city.ac.uk) 

 version 6.0a 29/01/2019
 Dr Eddie Edwards (Philip.Edwards@city.ac.uk)
*/


#include "game.h"


// Setup includes
#include "HighResolutionTimer.h"
#include "GameWindow.h"

// Game includes
#include "Camera.h"
#include "Skybox.h"
#include "Plane.h"
#include "Shaders.h"
#include "FreeTypeFont.h"
#include "Sphere.h"
#include "MatrixStack.h"
#include "OpenAssetImportMesh.h"
#include "Pyramid.h"
#include "Cube.h"
#include "CatmullRom.h"
#include "HeightMapTerrain.h"

// Constructor
Game::Game()
{
	m_pSkybox = NULL;
	m_pCamera = NULL;
	m_pShaderPrograms = NULL;
	m_pPlanarTerrain = NULL;
	m_pFtFont = NULL;
	m_pCamaroMesh = NULL;
	m_pCondorMesh = NULL;
	m_pCactusMesh = NULL;
	m_pSphere = NULL;
	m_pHighResolutionTimer = NULL;
	m_pPyramid = NULL;
	m_pCube = NULL;
	m_pCatmullRom = NULL;
	m_pHeightmapTerrain = NULL;

	m_dt = 0.0;
	m_framesPerSecond = 0;
	m_frameCount = 0;
	m_elapsedTime = 0.0f;
	m_timePassed = 0;
	m_currentDistance = 1000.0f;
	m_t = 0;
	m_condorPosition = glm::vec3(0);
	m_condorOrientation = glm::mat4(1);
	m_camaroPosition = glm::vec3(0);
	m_camaroOrientation = glm::mat4(1);
	m_rotY = 0;
}

// Destructor
Game::~Game() 
{ 
	//game objects
	delete m_pCamera;
	delete m_pSkybox;
	delete m_pPlanarTerrain;
	delete m_pFtFont;
	delete m_pCamaroMesh;
	delete m_pCondorMesh;
	delete m_pCactusMesh;
	delete m_pSphere;
	delete m_pPyramid;
	delete m_pCube;
	delete m_pCatmullRom;
	delete m_pHeightmapTerrain;

	if (m_pShaderPrograms != NULL) {
		for (unsigned int i = 0; i < m_pShaderPrograms->size(); i++)
			delete (*m_pShaderPrograms)[i];
	}
	delete m_pShaderPrograms;

	//setup objects
	delete m_pHighResolutionTimer;
}

// Initialisation:  This method only runs once at startup
void Game::Initialise() 
{
	// Set the clear colour and depth
	glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
	glClearDepth(1.0f);

	/// Create objects
	m_pCamera = new CCamera;
	m_pSkybox = new CSkybox;
	m_pShaderPrograms = new vector <CShaderProgram *>;
	m_pPlanarTerrain = new CPlane;
	m_pFtFont = new CFreeTypeFont;
	m_pCamaroMesh = new COpenAssetImportMesh;
	m_pCondorMesh = new COpenAssetImportMesh;
	m_pCactusMesh = new COpenAssetImportMesh;
	m_pSphere = new CSphere;
	m_pPyramid = new CPyramid;
	m_pCube = new CCube;
	m_pCatmullRom = new CCatmullRom;
	m_pHeightmapTerrain = new CHeightMapTerrain;

	RECT dimensions = m_gameWindow.GetDimensions();

	int width = dimensions.right - dimensions.left;
	int height = dimensions.bottom - dimensions.top;

	// Set the orthographic and perspective projection matrices based on the image size
	m_pCamera->SetOrthographicProjectionMatrix(width, height); 
	m_pCamera->SetPerspectiveProjectionMatrix(45.0f, (float) width / (float) height, 0.5f, 5000.0f);

	// Load shaders
	vector<CShader> shShaders;
	vector<string> sShaderFileNames;
	sShaderFileNames.push_back("mainShader.vert");
	sShaderFileNames.push_back("mainShader.frag");
	sShaderFileNames.push_back("textShader.vert");
	sShaderFileNames.push_back("textShader.frag");
	sShaderFileNames.push_back("toonShader.vert");
	sShaderFileNames.push_back("toonShader.frag");

	for (int i = 0; i < (int) sShaderFileNames.size(); i++) {
		string sExt = sShaderFileNames[i].substr((int) sShaderFileNames[i].size()-4, 4);
		int iShaderType;
		if (sExt == "vert") iShaderType = GL_VERTEX_SHADER;
		else if (sExt == "frag") iShaderType = GL_FRAGMENT_SHADER;
		else if (sExt == "geom") iShaderType = GL_GEOMETRY_SHADER;
		else if (sExt == "tcnl") iShaderType = GL_TESS_CONTROL_SHADER;
		else iShaderType = GL_TESS_EVALUATION_SHADER;
		CShader shader;
		shader.LoadShader("resources\\shaders\\"+sShaderFileNames[i], iShaderType);
		shShaders.push_back(shader);
	}

	// Create the main shader program
	CShaderProgram *pMainProgram = new CShaderProgram;
	pMainProgram->CreateProgram();
	pMainProgram->AddShaderToProgram(&shShaders[0]);
	pMainProgram->AddShaderToProgram(&shShaders[1]);
	pMainProgram->LinkProgram();
	m_pShaderPrograms->push_back(pMainProgram);

	// Create a shader program for fonts
	CShaderProgram *pFontProgram = new CShaderProgram;
	pFontProgram->CreateProgram();
	pFontProgram->AddShaderToProgram(&shShaders[2]);
	pFontProgram->AddShaderToProgram(&shShaders[3]);
	pFontProgram->LinkProgram();
	m_pShaderPrograms->push_back(pFontProgram);

	CShaderProgram* pToonShader = new CShaderProgram;
	pToonShader->CreateProgram();
	pToonShader->AddShaderToProgram(&shShaders[4]);
	pToonShader->AddShaderToProgram(&shShaders[5]);
	pToonShader->LinkProgram();
	m_pShaderPrograms->push_back(pToonShader);

	// You can follow this pattern to load additional shaders

	// Create the skybox
	// Skybox downloaded from https://opengameart.org/content/xonotic-skyboxes
	m_pSkybox->Create(2500.0f);

	m_pFtFont->LoadFont("resources\\fonts\\KaushanScript-Regular.otf", 32); // Downloaded from https://www.fontsquirrel.com/fonts/kaushan-script
	m_pFtFont->SetShaderProgram(pFontProgram);

	// Load some meshes in OBJ format
	m_pCamaroMesh->Load("resources\\models\\Camaro\\Chevrolet_Camaro_SS_Low.obj");  // Downloaded from https://free3d.com/3d-model/chevrolet-camaro-ss-coupe-373476.html 
	m_pCondorMesh->Load("resources\\models\\Condor\\CONDOR.obj");  // Downloaded from https://free3d.com/3d-model/condor-31418.html
	m_pCactusMesh->Load("resources\\models\\Cactus\\cactus.obj"); // Downloaded from https://free3d.com/3d-model/-cactus-v1--424886.html

	m_pPyramid->Create("resources\\textures\\sand 3.jpg"); // Downloaded from https://opengameart.org/content/sand-texture-pack
	m_pCube->Create("resources\\textures\\sand 3.jpg"); // Downloaded from https://opengameart.org/content/sand-texture-pack

	// Create the centre line of the path
	m_pCatmullRom->CreateCentreline();
	m_pCatmullRom->CreateOffsetCurves();
	m_pCatmullRom->CreateTrack();

	// Create the heightmap terrain
	m_pHeightmapTerrain->Create("resources\\textures\\terrainHeightMap200.bmp", "resources\\textures\\Sand 4.jpg", glm::vec3(0, 0, 0), 2000.0f, 2000.0f, 20.5f);

	viewpoint = "third";
}

// Render method runs repeatedly in a loop
void Game::Render() 
{
	
	// Clear the buffers and enable depth testing (z-buffering)
	glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glEnable(GL_DEPTH_TEST);

	// Set up a matrix stack
	glutil::MatrixStack modelViewMatrixStack;
	modelViewMatrixStack.SetIdentity();

	// Use the main shader program 
	CShaderProgram *pMainProgram = (*m_pShaderPrograms)[0];
	pMainProgram->UseProgram();
	pMainProgram->SetUniform("bUseTexture", true);
	pMainProgram->SetUniform("sampler0", 0);
	// Note: cubemap and non-cubemap textures should not be mixed in the same texture unit.  Setting unit 10 to be a cubemap texture.
	int cubeMapTextureUnit = 10; 
	pMainProgram->SetUniform("CubeMapTex", cubeMapTextureUnit);
	

	// Set the projection matrix
	pMainProgram->SetUniform("matrices.projMatrix", m_pCamera->GetPerspectiveProjectionMatrix());

	// Call LookAt to create the view matrix and put this on the modelViewMatrix stack. 
	// Store the view matrix and the normal matrix associated with the view matrix for later (they're useful for lighting -- since lighting is done in eye coordinates)
	modelViewMatrixStack.LookAt(m_pCamera->GetPosition(), m_pCamera->GetView(), m_pCamera->GetUpVector());
	glm::mat4 viewMatrix = modelViewMatrixStack.Top();
	glm::mat3 viewNormalMatrix = m_pCamera->ComputeNormalMatrix(viewMatrix);

	
	// Set light and materials in main shader program
	glm::vec4 lightPosition1 = glm::vec4(-100, 100, -100, 1); // Position of light source *in world coordinates*
	pMainProgram->SetUniform("light1.position", viewMatrix*glm::vec4(m_camaroPosition.x, 200, m_camaroPosition.z,1)); // Position of light source *in eye coordinates*
	pMainProgram->SetUniform("light1.La", glm::vec3(1.0f));		// Ambient colour of light
	pMainProgram->SetUniform("light1.Ld", glm::vec3(1.0f));		// Diffuse colour of light
	pMainProgram->SetUniform("light1.Ls", glm::vec3(1.0f));		// Specular colour of light
	pMainProgram->SetUniform("material1.Ma", glm::vec3(1.0f));	// Ambient material reflectance
	pMainProgram->SetUniform("material1.Md", glm::vec3(0.0f));	// Diffuse material reflectance
	pMainProgram->SetUniform("material1.Ms", glm::vec3(0.0f));	// Specular material reflectance
	pMainProgram->SetUniform("material1.shininess", 15.0f);		// Shininess material property
	

	// Render the skybox and terrain with full ambient reflectance 
	modelViewMatrixStack.Push();
		pMainProgram->SetUniform("renderSkybox", true);
		// Translate the modelview matrix to the camera eye point so skybox stays centred around camera
		glm::vec3 vEye = m_pCamera->GetPosition();
		modelViewMatrixStack.Translate(vEye);
		pMainProgram->SetUniform("matrices.modelViewMatrix", modelViewMatrixStack.Top());
		pMainProgram->SetUniform("matrices.normalMatrix", m_pCamera->ComputeNormalMatrix(modelViewMatrixStack.Top()));
		m_pSkybox->Render(cubeMapTextureUnit);
		pMainProgram->SetUniform("renderSkybox", false);
	modelViewMatrixStack.Pop();


	// Turn on diffuse + specular materials
	pMainProgram->SetUniform("material1.Ma", glm::vec3(0.5f));	// Ambient material reflectance
	pMainProgram->SetUniform("material1.Md", glm::vec3(0.5f));	// Diffuse material reflectance
	pMainProgram->SetUniform("material1.Ms", glm::vec3(1.0f));	// Specular material reflectance	

	// Render the new terrain
	modelViewMatrixStack.Push();
	modelViewMatrixStack.Translate(glm::vec3(0.0f, 2.0f, 0.0f));
	pMainProgram->SetUniform("matrices.modelViewMatrix", modelViewMatrixStack.Top());
	pMainProgram->SetUniform("matrices.normalMatrix", m_pCamera->ComputeNormalMatrix(modelViewMatrixStack.Top()));
	m_pHeightmapTerrain->Render();
	modelViewMatrixStack.Pop();
	

	// Render the condor
	modelViewMatrixStack.Push();
		modelViewMatrixStack.Translate(glm::vec3(0.0f, 100.0f, 0.0f));
		modelViewMatrixStack.Translate(m_condorPosition);
		modelViewMatrixStack.Rotate(glm::vec3(0.0f, 1.0f, 0.0f), 1.57f);
		modelViewMatrixStack *= m_condorOrientation;
		modelViewMatrixStack.Scale(1.0f);
		pMainProgram->SetUniform("matrices.modelViewMatrix", modelViewMatrixStack.Top());
		pMainProgram->SetUniform("matrices.normalMatrix", m_pCamera->ComputeNormalMatrix(modelViewMatrixStack.Top()));
		m_pCondorMesh->Render();
	modelViewMatrixStack.Pop();

	// Render the second condor
	modelViewMatrixStack.Push();
	modelViewMatrixStack.Translate(glm::vec3(-650.0f, 30.0f, 550.0f));
	modelViewMatrixStack.Translate(m_condorPosition);
	modelViewMatrixStack.Rotate(glm::vec3(0.0f, 1.0f, 0.0f), 1.57f);
	modelViewMatrixStack *= m_condorOrientation;
	modelViewMatrixStack.Scale(1.0f);
	pMainProgram->SetUniform("matrices.modelViewMatrix", modelViewMatrixStack.Top());
	pMainProgram->SetUniform("matrices.normalMatrix", m_pCamera->ComputeNormalMatrix(modelViewMatrixStack.Top()));
	m_pCondorMesh->Render();
	modelViewMatrixStack.Pop();

	// Render the third condor
	modelViewMatrixStack.Push();
	modelViewMatrixStack.Translate(glm::vec3(550.0f, 30.0f, -550.0f));
	modelViewMatrixStack.Translate(m_condorPosition);
	modelViewMatrixStack.Rotate(glm::vec3(0.0f, 1.0f, 0.0f), 1.57f);
	modelViewMatrixStack *= m_condorOrientation;
	modelViewMatrixStack.Scale(1.0f);
	pMainProgram->SetUniform("matrices.modelViewMatrix", modelViewMatrixStack.Top());
	pMainProgram->SetUniform("matrices.normalMatrix", m_pCamera->ComputeNormalMatrix(modelViewMatrixStack.Top()));
	m_pCondorMesh->Render();
	modelViewMatrixStack.Pop();

	// Render the cactus
	modelViewMatrixStack.Push();
	modelViewMatrixStack.Translate(glm::vec3(-650.0f, -5.0f, 650.0f));
//	modelViewMatrixStack.Rotate(glm::vec3(0.0f, 0.0f, 1.0f), 1.57f);
	modelViewMatrixStack.Scale(5.0f);
	pMainProgram->SetUniform("matrices.modelViewMatrix", modelViewMatrixStack.Top());
	pMainProgram->SetUniform("matrices.normalMatrix", m_pCamera->ComputeNormalMatrix(modelViewMatrixStack.Top()));
	m_pCactusMesh->Render();
	modelViewMatrixStack.Pop();

	// Render the second cactus
	modelViewMatrixStack.Push();
	modelViewMatrixStack.Translate(glm::vec3(590.0f, -5.0f, -590.0f));
	//modelViewMatrixStack.Rotate(glm::vec3(0.0f, 0.0f, 1.0f), 1.57f);
	modelViewMatrixStack.Scale(5.0f);
	pMainProgram->SetUniform("matrices.modelViewMatrix", modelViewMatrixStack.Top());
	pMainProgram->SetUniform("matrices.normalMatrix", m_pCamera->ComputeNormalMatrix(modelViewMatrixStack.Top()));
	m_pCactusMesh->Render();
	modelViewMatrixStack.Pop();

	// Render the third cactus
	modelViewMatrixStack.Push();
	modelViewMatrixStack.Translate(glm::vec3(590.0f, -5.0f, 590.0f));
	//modelViewMatrixStack.Rotate(glm::vec3(0.0f, 0.0f, 1.0f), 1.57f);
	modelViewMatrixStack.Scale(5.0f);
	pMainProgram->SetUniform("matrices.modelViewMatrix", modelViewMatrixStack.Top());
	pMainProgram->SetUniform("matrices.normalMatrix", m_pCamera->ComputeNormalMatrix(modelViewMatrixStack.Top()));
	m_pCactusMesh->Render();
	modelViewMatrixStack.Pop();

	// Render the fourth cactus
	modelViewMatrixStack.Push();
	modelViewMatrixStack.Translate(glm::vec3(-590.0f, -5.0f, -590.0f));
	//modelViewMatrixStack.Rotate(glm::vec3(0.0f, 0.0f, 1.0f), 1.57f);
	modelViewMatrixStack.Scale(5.0f);
	pMainProgram->SetUniform("matrices.modelViewMatrix", modelViewMatrixStack.Top());
	pMainProgram->SetUniform("matrices.normalMatrix", m_pCamera->ComputeNormalMatrix(modelViewMatrixStack.Top()));
	m_pCactusMesh->Render();
	modelViewMatrixStack.Pop();


	
	// Render the camaro 
	modelViewMatrixStack.Push();
		modelViewMatrixStack.Translate(m_camaroPosition);
		modelViewMatrixStack.Translate(glm::vec3(0.0f, 7.0f, 0.0f));
		modelViewMatrixStack.Rotate(glm::vec3(0.0f, 1.0f, 0.0f), 1.57f);
		modelViewMatrixStack *= m_camaroOrientation;
		modelViewMatrixStack.Scale(5.0f);
		pMainProgram->SetUniform("matrices.modelViewMatrix", modelViewMatrixStack.Top());
		pMainProgram->SetUniform("matrices.normalMatrix", m_pCamera->ComputeNormalMatrix(modelViewMatrixStack.Top()));
		m_pCamaroMesh->Render();
	modelViewMatrixStack.Pop();
	

	// Render the pyramid
	modelViewMatrixStack.Push();
	modelViewMatrixStack.Translate(glm::vec3(-450.0f, 0.0f, 450.0f));
	modelViewMatrixStack.Scale(150.0f);
	pMainProgram->SetUniform("matrices.modelViewMatrix", modelViewMatrixStack.Top());
	pMainProgram->SetUniform("matrices.normalMatrix", m_pCamera->ComputeNormalMatrix(modelViewMatrixStack.Top()));
	m_pPyramid->Render();
	modelViewMatrixStack.Pop();

	// Render the second pyramid
	modelViewMatrixStack.Push();
	modelViewMatrixStack.Translate(glm::vec3(0.0f, 0.0f, 0.0f));
	modelViewMatrixStack.Scale(200.0f);
	pMainProgram->SetUniform("matrices.modelViewMatrix", modelViewMatrixStack.Top());
	pMainProgram->SetUniform("matrices.normalMatrix", m_pCamera->ComputeNormalMatrix(modelViewMatrixStack.Top()));
	m_pPyramid->Render();
	modelViewMatrixStack.Pop();

	// Render the third pyramid
	modelViewMatrixStack.Push();
	modelViewMatrixStack.Translate(glm::vec3(350.0f, 0.0f, -450.0f));
	modelViewMatrixStack.Scale(150.0f);
	pMainProgram->SetUniform("matrices.modelViewMatrix", modelViewMatrixStack.Top());
	pMainProgram->SetUniform("matrices.normalMatrix", m_pCamera->ComputeNormalMatrix(modelViewMatrixStack.Top()));
	m_pPyramid->Render();
	modelViewMatrixStack.Pop();


	// Render the path
	modelViewMatrixStack.Push();
	pMainProgram->SetUniform("bUseTexture", true); // turn off texturing
	//pMainProgram->SetUniform("matrices.projMatrix", m_pCamera->GetPerspectiveProjectionMatrix());
	pMainProgram->SetUniform("matrices.modelViewMatrix", modelViewMatrixStack.Top());
	pMainProgram->SetUniform("matrices.normalMatrix",
		m_pCamera->ComputeNormalMatrix(modelViewMatrixStack.Top()));
	m_pCatmullRom->RenderTrack();
	modelViewMatrixStack.Pop();

	CShaderProgram *pToonShader = (*m_pShaderPrograms)[2];
	pToonShader->UseProgram();
	pToonShader->SetUniform("bUseTexture", false);
	pToonShader->SetUniform("levels", 6);

	// Set light and materials in toon programme
	pToonShader->SetUniform("material1.Ma", glm::vec3(1.0f, 1.0f, 0.0f));
	pToonShader->SetUniform("material1.Md", glm::vec3(1.0f, 1.0f, 0.0f));
	pToonShader->SetUniform("material1.Ms", glm::vec3(1.0f, 1.0f, 1.0f));
	pToonShader->SetUniform("material1.shininess", 50.0f);
	pToonShader->SetUniform("light1.La", glm::vec3(0.15f, 0.15f, 0.15f));
	pToonShader->SetUniform("light1.Ld", glm::vec3(1.0f, 0.0f, 0.0f));
	pToonShader->SetUniform("light1.Ls", glm::vec3(1.0f, 1.0f, 1.0f));
	pToonShader->SetUniform("light1.position", viewMatrix);

	for (int i = 0; i < m_pCatmullRom->GetRightOffsets().size(); i += 40)
	{
		// Render the cube
		modelViewMatrixStack.Push();
		modelViewMatrixStack.Translate(m_pCatmullRom->GetCentreline()[i]);
		modelViewMatrixStack.Translate(glm::vec3(0.0f, 5.0f, 0.0f));
		modelViewMatrixStack.Rotate(glm::vec3(0, 1, 0), m_rotY);
		modelViewMatrixStack.Scale(4.0f);
		pToonShader->SetUniform("bUseTexture", FALSE); // turn on texturing
		pToonShader->SetUniform("matrices.projMatrix", m_pCamera->GetPerspectiveProjectionMatrix());
		pToonShader->SetUniform("matrices.modelViewMatrix", modelViewMatrixStack.Top());
		pToonShader->SetUniform("matrices.normalMatrix", m_pCamera->ComputeNormalMatrix(modelViewMatrixStack.Top()));
		m_pCube->Render();
		modelViewMatrixStack.Pop();
	}
		
	// Draw the 2D graphics after the 3D graphics
	DisplayFrameRate();

	RECT dimensions = m_gameWindow.GetDimensions();
	int height = dimensions.bottom - dimensions.top;
	m_pFtFont->Render(20, height - 550, 20, "TIME: %d", int(m_timePassed* 0.001f));

	// Swap buffers to show the rendered image
	SwapBuffers(m_gameWindow.Hdc());		

}

// Update method runs repeatedly with the Render method
void Game::Update()
{

	ChangeViewPoint(viewpoint);

	m_timePassed += m_dt;

	// Set the up vector
	glm::vec3 up = glm::vec3(0, 1, 0);

	// Update the position of the condor to be moving in a circle
	m_t += .001 * m_dt;
	float r = 75.0f;
	glm::vec3 x = glm::vec3(1, 0, 0);
	glm::vec3 y = glm::vec3(0, 1, 0);
	glm::vec3 z = glm::vec3(0, 0, 1);
	m_condorPosition = r * cos(m_t) * x + 50.0f * y + r * sin(m_t) * z;


	// Update the orientation of the condor
	glm::vec3 T = glm::normalize(-sin(m_t) * x + cos(m_t) * z);
	glm::vec3 N = glm::normalize(glm::cross(T, y));
	glm::vec3 B = glm::normalize(glm::cross(N, T));
	m_condorOrientation = glm::mat4(glm::mat3(T, B, N));


	// Set control to move the path forward
	if (GetKeyState('G')& 0x80)
	{
		m_currentDistance = m_currentDistance + (m_dt * 0.1f);
	}

	// Set control to move the path backwards
	if (GetKeyState('B')& 0x80)
	{
		m_currentDistance = m_currentDistance - (m_dt * 0.1f);
	}

	m_rotY += 0.001f * m_dt;
}



void Game::DisplayFrameRate()
{


	CShaderProgram *fontProgram = (*m_pShaderPrograms)[1];

	RECT dimensions = m_gameWindow.GetDimensions();
	int height = dimensions.bottom - dimensions.top;

	// Increase the elapsed time and frame counter
	m_elapsedTime += m_dt;
	m_frameCount++;

	// Now we want to subtract the current time by the last time that was stored
	// to see if the time elapsed has been over a second, which means we found our FPS.
	if (m_elapsedTime > 1000)
    {
		m_elapsedTime = 0;
		m_framesPerSecond = m_frameCount;

		// Reset the frames per second
		m_frameCount = 0;
    }

	if (m_framesPerSecond > 0) {
		// Use the font shader program and render the text
		fontProgram->UseProgram();
		glDisable(GL_DEPTH_TEST);
		fontProgram->SetUniform("matrices.modelViewMatrix", glm::mat4(1));
		fontProgram->SetUniform("matrices.projMatrix", m_pCamera->GetOrthographicProjectionMatrix());
		fontProgram->SetUniform("vColour", glm::vec4(1.0f, 1.0f, 1.0f, 1.0f));
		m_pFtFont->Render(20, height - 20, 20, "FPS: %d", m_framesPerSecond);
	}
}

// The game loop runs repeatedly until game over
void Game::GameLoop()
{	
	// Variable timer
	m_pHighResolutionTimer->Start();
	Update();
	Render();
	m_dt = m_pHighResolutionTimer->Elapsed();

}


WPARAM Game::Execute() 
{
	m_pHighResolutionTimer = new CHighResolutionTimer;
	m_gameWindow.Init(m_hInstance);

	if(!m_gameWindow.Hdc()) {
		return 1;
	}

	Initialise();

	m_pHighResolutionTimer->Start();

	
	MSG msg;

	while(1) {													
		if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) { 
			if(msg.message == WM_QUIT) {
				break;
			}

			TranslateMessage(&msg);	
			DispatchMessage(&msg);
		} else if (m_appActive) {
			GameLoop();
		} 
		else Sleep(200); // Do not consume processor power if application isn't active
	}

	m_gameWindow.Deinit();

	return(msg.wParam);
}

LRESULT Game::ProcessEvents(HWND window,UINT message, WPARAM w_param, LPARAM l_param) 
{
	LRESULT result = 0;

	switch (message) {


	case WM_ACTIVATE:
	{
		switch(LOWORD(w_param))
		{
			case WA_ACTIVE:
			case WA_CLICKACTIVE:
				m_appActive = true;
				m_pHighResolutionTimer->Start();
				break;
			case WA_INACTIVE:
				m_appActive = false;
				break;
		}
		break;
		}

	case WM_SIZE:
			RECT dimensions;
			GetClientRect(window, &dimensions);
			m_gameWindow.SetDimensions(dimensions);
		break;

	case WM_PAINT:
		PAINTSTRUCT ps;
		BeginPaint(window, &ps);
		EndPaint(window, &ps);
		break;

	case WM_KEYDOWN:
		switch(w_param) {
		case VK_ESCAPE:
			PostQuitMessage(0);
			break;
		case '1':
			viewpoint = "first";
			break;
		case '2':
			viewpoint = "top";
			break;
		case '3':
			viewpoint = "third";
			break;
		case '4':
			viewpoint = "free";
			break;
		}
		break;

	case WM_DESTROY:
		PostQuitMessage(0);
		break;

	default:
		result = DefWindowProc(window, message, w_param, l_param);
		break;
	}

	return result;
}

Game& Game::GetInstance() 
{
	static Game instance;

	return instance;
}

void Game::SetHinstance(HINSTANCE hinstance) 
{
	m_hInstance = hinstance;
}

LRESULT CALLBACK WinProc(HWND window, UINT message, WPARAM w_param, LPARAM l_param)
{
	return Game::GetInstance().ProcessEvents(window, message, w_param, l_param);
}

int WINAPI WinMain(HINSTANCE hinstance, HINSTANCE, PSTR, int) 
{
	Game &game = Game::GetInstance();
	game.SetHinstance(hinstance);

	return game.Execute();
}

void Game::ChangeViewPoint(string viewpoint) {

	// Set positions and view points for the camera 
	glm::vec3 p;
	glm::vec3 upvec = glm::vec3(0, 1, 0);
	glm::vec3 pos = glm::vec3(0, 0, 0);
	glm::vec3 pNext;
	glm::vec3 pPrev;

	m_pCatmullRom->Sample(m_currentDistance, p, upvec);
	m_pCatmullRom->Sample(m_currentDistance + 1.0f, pNext, upvec);
	m_pCatmullRom->Sample(m_currentDistance - 30.0f, pPrev, upvec);

	glm::vec3 pUp = p + glm::vec3(0,10,0);
	

	T = glm::normalize(pNext - p);
	N = glm::normalize(glm::cross(T, upvec));
	B = glm::normalize(glm::cross(N, T));

	m_camaroOrientation = glm::mat4(glm::mat3(T, B, N));

	glm::vec3 first = (p + 30.0f * T);
	m_camaroPosition = pPrev;

	glm::vec3 pTop = pPrev + glm::vec3(0, 500, 0);

	glm::vec3 pThird = (pPrev - 40.0f * T) + (B * 20.0f);

	// Set camera, position and up vector based on input

	if (viewpoint == "first") {
		m_pCamera->Set(pUp, first, upvec);
	}
	if (viewpoint == "third") {
		m_pCamera->Set(pThird, pNext, B);
	}
	if (viewpoint == "top") {
		m_pCamera->Set(pTop, pPrev, T);
	}
	if (viewpoint == "free") {
		m_pCamera->Update(m_dt);
	}
}